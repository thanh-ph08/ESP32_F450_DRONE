#include "Debug_Espfc.h"

namespace Espfc
{

#ifdef ESPFC_DEBUG_SERIAL
Stream * _debugStream = nullptr;
#endif

}
